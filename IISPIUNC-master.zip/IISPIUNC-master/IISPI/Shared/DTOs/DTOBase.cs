﻿using IISPI.Shared.ENUM;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IISPI.Shared.DTOs
{
    public class DTOBase 
    {
        public int Id { get; set; }
    }
}
