﻿namespace IISPI.Shared.DTOs
{
    public class ReporteItemMedidoZonaDTO
    {
        public DateOnly? Fecha { get; set; }
        public string Codigo { get; set; }
        public string Item { get; set; }
        public string Unidad { get; set; }
        public string Zona1 { get; set; }
        public string Zona2{ get; set; }
        public string Zona3 { get; set; }
        public string Zona4 { get; set; }
        public string Zona5 { get; set; }
        public string Zona6 { get; set; }
    }
}
