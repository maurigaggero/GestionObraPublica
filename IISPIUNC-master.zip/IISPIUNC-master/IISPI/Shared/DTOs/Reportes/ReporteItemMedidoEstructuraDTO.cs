﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IISPI.Shared.DTOs
{
    public class ReporteItemMedidoEstructuraDTO
    {
        public DateOnly? Fecha { get; set; }
        public string Contrato { get; set; }
        public string Estructura { get; set; }
        public string Codigo { get; set; }
        public string Item { get; set; }
        public string Unidad { get; set; }
        public string Periodo1 { get; set; }
        public string Periodo2{ get; set; }
        public string Periodo3 { get; set; }
        public string Periodo4 { get; set; }
        public string Periodo5 { get; set; }
        public string Periodo6 { get; set; }
        public string Periodo7 { get; set; }
        public string Periodo8 { get; set; }
        public string Periodo9 { get; set; }
        public string Periodo10 { get; set; }
        public string Periodo11 { get; set; }
        public string Periodo12 { get; set; }
        public string Periodo13 { get; set; }
        public string Periodo14 { get; set; }
        public string Periodo15 { get; set; }
        public string Periodo16 { get; set; }
        public string Periodo17 { get; set; }
        public string Periodo18 { get; set; }
    }
}
