﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IISPI.Shared.ENUM
{
    public enum EnumEstadoCertificacion
	{
        Iniciado = 0,
        Rechazado = 1,
        Aceptado = 2,
        Estudio = 3,
        Observado = 4
    }
}
