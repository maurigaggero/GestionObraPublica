﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IISPI.Shared.ENUM
{
    public enum EnumEstadoRegistro
    {
        activo = 0,
        inactivo = 1, 
        borrado = 2
    }
}
