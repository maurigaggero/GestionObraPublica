﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IISPI.Shared.ENUM
{
    public enum TipoParam
    {
        Informar = 0,
        Comparar = 1,
        Dato = 2,
        Documento = 3
    }
}
