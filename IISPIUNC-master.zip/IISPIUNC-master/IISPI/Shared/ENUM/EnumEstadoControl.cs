﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IISPI.Shared.ENUM
{
    public enum EnumEstadoControl
    {
        SIN_DATO = 0,
        REALIZADO_ACEPTADO = 1,
        REALIZADO_RECHAZADO = 2,
        REALIZADO_SIN_DATO = 3
    }
}