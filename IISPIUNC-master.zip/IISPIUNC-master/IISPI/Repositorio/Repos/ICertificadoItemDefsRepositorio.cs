﻿using IISPI.BD.Data.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IISPI.Repositorio.Repos
{
    public interface ICertificadoItemDefRepositorio : IRepositorio<CertificadoItemDef>
    {
        Task<List<CertificadoItemDef>> GetCertificadosDefByIdCertificado(int id);
        bool DeleteUpdate(List<CertificadoItemDef> certificadoItemDefs, List<CertificadoItem> certitems);
        Task<List<CertificadoItemDef>> GetCertificadosDefByIdContrato(int idContrato);
    }
}
