﻿using IISPI.BD.Data.Entity;
using IISPI.Shared.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IISPI.Repositorio.Repos
{
    public interface IContratoEstructuraRepositorio : IRepositorio<ContratoEstructura>
    {
        Task<List<ContratoEstructura>> GetContratoEstructuras(int contratoId);
        Task<List<ContratoEstructura>> GetContratoEstructurasByContratoId(PaginacionDTO paginacion, int id);
        Task<ContratoEstructura> GetContratoEstructuraById(int id);

    }
}
