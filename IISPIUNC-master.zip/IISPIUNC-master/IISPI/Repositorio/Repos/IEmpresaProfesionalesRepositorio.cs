﻿using IISPI.BD.Data.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IISPI.Repositorio.Repos
{
    public interface IEmpresaProfesionalesRepositorio : IRepositorio<EmpresaProfesional>
    {
        Task<List<EmpresaProfesional>> GetEmpProfesionales(int id);
        Task<EmpresaProfesional> GetEmpProfesionalfById(int id);
    }
}
