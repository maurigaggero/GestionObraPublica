﻿using IISPI.BD.Data;
using IISPI.BD.Data.Entity;

namespace IISPI.Repositorio.Repos
{
    public class CalleRepositorio : Repositorio<Calle>, ICalleRepositorio
    {
        public CalleRepositorio(BDContext context) : base(context)
        {
        }
    }
}
