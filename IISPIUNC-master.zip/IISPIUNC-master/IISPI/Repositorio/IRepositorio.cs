﻿using IISPI.BD.Data;
using IISPI.BD.Data.Entity;

namespace IISPI.Repositorio
{
    public interface IRepositorio<E>
    {
        BDContext Context { get; }
        Task<bool> Baja(int id, string usuarioId);
        Task<List<E>> GetActivos();
        Task<E> GetById(int id);
        Task<List<E>> GetFull();
        Task<int> Insert(E entity);
        Task<bool> Update(E entrada, int id);
    }
}