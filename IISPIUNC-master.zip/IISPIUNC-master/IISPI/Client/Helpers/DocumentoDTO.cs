﻿namespace IISPI.Client.Helpers
{
    public class DocumentoDTO
    {
        public string PathDoc { get; set; }

        public string File { get; set; }

        public string Extension { get; set; }
    }
}
